"""
categories/seniors.py — Seniors et Vétérans (V1→V4).

Règles métier :
  - Seniors : CDF, nationalité française, sélection N1 / N2-régional
  - V1/V2 : Vétérans (même logique)
  - V3/V4 : Grands Vétérans
"""
from .base import BaseCategorie
from ..core.utils import filtrer_df, est_grand_est, COL_RANG, COL_NOM, COL_PRENOM, COL_CLUB, COL_REGION
from ..core.styles import COULEUR_N1, COULEUR_N2, get_palette


def _construire_seniors(df_national, df_regional, config: dict) -> dict:
    """Logique commune Seniors / Vétérans : sections N1 et N2-régional."""
    quota_n1      = config.get("quota_n1",     32)
    quota_n2      = config.get("quota_n2_reg",  0)
    filtre_fr     = config.get("nationalite_francaise", True)
    cat_id        = config.get("cat_id", "Seniors")
    niveau_lrege  = config.get("niveau_lrege", "N3")  # N2 ou N3 selon réglementation
    # Wild Cards DTN : Seniors uniquement, pas pour les Vétérans
    nb_wc       = config.get("nb_wildcards", 4) if cat_id == "Seniors" else 0
    pal         = get_palette(cat_id)

    df_nat = filtrer_df(df_national, filtre_fr)
    df_reg = filtrer_df(df_regional, filtre_fr)

    # ── N1 : top quota_n1 du classement national ────────────────────
    n1_df = df_nat[df_nat[COL_REGION].apply(est_grand_est)].head(quota_n1)
    tireurs_n1 = [
        {"rang": f"CL NAT {r[COL_RANG]}", "nom": r[COL_NOM],
         "prenom": r[COL_PRENOM], "club": r[COL_CLUB], "note": ""}
        for _, r in n1_df.iterrows()
    ]
    noms_n1 = {(r[COL_NOM], r[COL_PRENOM]) for _, r in n1_df.iterrows()}

    # ── Wild Cards DTN : afficher seulement si tireurs GE dans la zone WC (rangs 33-36) ──
    if nb_wc > 0:
        ge_zone_wc = df_nat[
            (df_nat[COL_RANG] > quota_n1) &
            (df_nat[COL_RANG] <= quota_n1 + nb_wc) &
            df_nat[COL_REGION].apply(est_grand_est)
        ]
        if not ge_zone_wc.empty:
            for i in range(1, nb_wc + 1):
                tireurs_n1.append({
                    "rang": f"WC {i}/{nb_wc}", "nom": "", "prenom": "",
                    "club": "", "note": "Wild Card DTN"
                })
        else:
            nb_wc = 0  # pas de WC pertinente pour le GE

    # ── N2 : classement régional hors N1 ───────────────────────────
    tireurs_n2 = []
    if quota_n2 > 0:
        n2_df = df_reg[
            ~df_reg.apply(lambda r: (r[COL_NOM], r[COL_PRENOM]) in noms_n1, axis=1)
        ].head(quota_n2)
        tireurs_n2 = [
            {"rang": f"CL GE {r[COL_RANG]}", "nom": r[COL_NOM],
             "prenom": r[COL_PRENOM], "club": r[COL_CLUB], "note": ""}
            for _, r in n2_df.iterrows()
        ]

    textes_n1 = config.get("textes_n1", [
        f"Les {quota_n1} premiers du classement national",
        f"+ jusqu'à {nb_wc} Wild Card{'s' if nb_wc > 1 else ''} attribuée{'s' if nb_wc > 1 else ''} par la DTN",
        "Les absents non remplacés par WC : le suivant au classement national est sélectionné"
    ])
    textes_n2 = config.get("textes_n2", [])

    sections = [
        {
            "label": "TIREURS QUALIFIÉS — N1 (QUOTA FÉDÉRAL)",
            "couleur": pal["n1"],
            "textes": textes_n1,
            "tireurs": tireurs_n1,
            "avec_participation": True,
        },
    ]
    if quota_n2 > 0:
        sections.append({
            "label": f"TIREURS QUALIFIÉS — QUOTA LREGE {niveau_lrege}",
            "couleur": pal["n2"],
            "textes": textes_n2,
            "tireurs": tireurs_n2,
            "avec_participation": True,
        })

    return {
        "format": "seniors",
        "meta": {
            "region": "Grand Est",
            "cat_id":                   cat_id,
            "cat_label":                config.get("cat_label", cat_id),
            "competition":              config.get("competition", "Championnat de France"),
            "date":                     config.get("date", ""),
            "lieu":                     config.get("lieu", ""),
            "discipline":               config.get("discipline", ""),
            "mail_retour":              config.get("mail_retour", "administration@crege.fr"),
            "date_limite_retour":       config.get("date_limite_retour", ""),
            "date_engagement_extranet": config.get("date_engagement_extranet", ""),
            "arbitrage_config":         config.get("arbitrage_config", {}),
        },
        "sections": sections,
        "equipes": [],
    }


def _make_seniors_class(cat_id, label, competitions, nationalite_fr=True):
    """Factory pour créer les classes Seniors/Vétérans partageant la même logique."""
    class _Cat(BaseCategorie):
        CAT_ID         = cat_id
        LABEL          = label
        FORMAT         = "seniors"
        COMPETITIONS   = competitions
        NATIONALITE_FR = nationalite_fr

        def construire(self, df_national, df_regional, config: dict) -> dict:
            return _construire_seniors(df_national, df_regional, config)

        def generer(self, data: dict):
            from ..generateur.excel import generer_feuille_simple
            from openpyxl import Workbook
            wb = Workbook(); ws = wb.active; ws.title = "Sélection"
            generer_feuille_simple(ws, data)
            return wb

    _Cat.__name__ = cat_id
    return _Cat


Seniors = _make_seniors_class("Seniors", "Seniors",    ["Championnat de France"], True)
V1      = _make_seniors_class("V1",      "Vétérans V1", ["Championnat de France"], False)
V2      = _make_seniors_class("V2",      "Vétérans V2", ["Championnat de France"], False)
V3      = _make_seniors_class("V3",      "Grands Vétérans V3", ["Championnat de France"], False)
V4      = _make_seniors_class("V4",      "Grands Vétérans V4", ["Championnat de France"], False)
